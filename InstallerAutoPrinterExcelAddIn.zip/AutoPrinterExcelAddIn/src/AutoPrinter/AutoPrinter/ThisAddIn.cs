﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Excel;

namespace AutoPrinter
{

    public partial class ThisAddIn
    {
        public Range setTargetCell()
        {
            Range rng = (Range)Globals.ThisAddIn.Application.Selection;
            return rng;
        }

        public void autoprint(string args, int arg_target_cell_x, int arg_target_cell_y, int arg_for_start, int arg_for_end, int arg_for_step)
        {
            
            Excel.Worksheet activeWorksheet = ((Excel.Worksheet)Application.ActiveSheet);
            //int x = arg_target_cell_x;
            //int y = arg_target_cell_y;

            //Range rng_zero = (Range)Globals.ThisAddIn.Application.ActiveSheet.Cells[1, 1];
            Range rng = (Range)Globals.ThisAddIn.Application.Selection;
            

            for (int i = arg_for_start; i <= arg_for_end; i = i + arg_for_step)
            {
                rng[1, 1] = i;

                if (args == "print")
                {
                    activeWorksheet.PrintOut();
                }

                if (args == "preview")
                {

                }
            }
        }

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO で生成されたコード

        /// <summary>
        /// デザイナーのサポートに必要なメソッドです。
        /// このメソッドの内容をコード エディターで変更しないでください。
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion
    }
}
